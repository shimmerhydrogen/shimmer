function Reyn=ReynoldsNum(rho,vel,D,DynVisc)

Reyn=(rho.*vel.*D)./DynVisc;

end